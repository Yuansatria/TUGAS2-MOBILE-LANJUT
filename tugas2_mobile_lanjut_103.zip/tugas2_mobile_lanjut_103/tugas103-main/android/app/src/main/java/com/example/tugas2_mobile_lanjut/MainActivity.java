package com.example.tugas2_mobile_lanjut;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
